CREATE DATABASE expense_tracker;

USE expense_tracker;

CREATE TABLE users (
    user_id INT PRIMARY KEY,
    user_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE,
    created_date DATE
);
CREATE TABLE categories (
    category_id INT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL,
    category_type VARCHAR(10) CHECK (category_type IN ('Income', 'Expense'))
);
CREATE TABLE payment_methods (
    payment_id INT PRIMARY KEY,
    payment_method VARCHAR(30) NOT NULL
);

CREATE TABLE transactions (
    transaction_id INT PRIMARY KEY,
    user_id INT,
    category_id INT,
    payment_id INT,
    amount DECIMAL(10,2) NOT NULL,
    transaction_date DATE NOT NULL,
    description VARCHAR(100),

    -- Foreign Key Constraints
    CONSTRAINT fk_user
        FOREIGN KEY (user_id)
        REFERENCES users(user_id),

    CONSTRAINT fk_category
        FOREIGN KEY (category_id)
        REFERENCES categories(category_id),

    CONSTRAINT fk_payment
        FOREIGN KEY (payment_id)
        REFERENCES payment_methods(payment_id)
);

INSERT INTO users VALUES
(1, 'Vani', 'vani@gmail.com', '2024-01-01'),
(2, 'Vijay', 'Vijay@gmail.com', '2024-02-10');

INSERT INTO categories VALUES
(1, 'Salary', 'Income'),
(2, 'Food', 'Expense'),
(3, 'Rent', 'Expense'),
(4, 'Transport', 'Expense'),
(5, 'Entertainment', 'Expense'),
(6, 'Shopping', 'Expense');

INSERT INTO payment_methods VALUES
(1, 'Cash'),
(2, 'UPI'),
(3, 'Debit Card'),
(4, 'Credit Card');

INSERT INTO transactions VALUES
(1, 1, 1, 2, 40000, '2024-01-01', 'January Salary'),
(2, 1, 3, 2, 12000, '2024-01-02', 'House Rent'),
(3, 1, 2, 1, 350, '2024-01-03', 'Lunch'),
(4, 1, 4, 2, 200, '2024-01-04', 'Bus Fare'),
(5, 1, 5, 3, 1500, '2024-01-05', 'Movie'),
(6, 1, 6, 4, 3000, '2024-01-06', 'Shopping'),
(7, 2, 1, 2, 30000, '2024-01-01', 'Salary'),
(8, 2, 2, 1, 500, '2024-01-03', 'Dinner'),
(9, 2, 3, 2, 10000, '2024-01-02', 'Rent');


SELECT * FROM users;
SELECT * FROM categories;
SELECT * FROM payment_methods;
SELECT * FROM transactions;

SELECT 
    u.user_name,
    c.category_name,
    c.category_type,
    t.amount,
    p.payment_method,
    t.transaction_date
FROM transactions t
JOIN users u ON t.user_id = u.user_id
JOIN categories c ON t.category_id = c.category_id
JOIN payment_methods p ON t.payment_id = p.payment_id;


##### 1. What is the total income and total expense for each user?
SELECT 
    u.user_name,
    c.category_type,
    SUM(t.amount) AS total_amount
FROM transactions t
JOIN users u ON t.user_id = u.user_id
JOIN categories c ON t.category_id = c.category_id
GROUP BY u.user_name, c.category_type;

###### 2.How much does each user spend in each expense category?
SELECT 
    u.user_name,
    c.category_name,
    SUM(t.amount) AS total_spent
FROM transactions t
JOIN users u ON t.user_id = u.user_id
JOIN categories c ON t.category_id = c.category_id
WHERE c.category_type = 'Expense'
GROUP BY u.user_name, c.category_name
ORDER BY total_spent DESC;

###### 3.What is the monthly expense trend for each user?
SELECT 
    u.user_name,
    EXTRACT(MONTH FROM t.transaction_date) AS month,
    SUM(t.amount) AS monthly_expense
FROM transactions t
JOIN users u ON t.user_id = u.user_id
JOIN categories c ON t.category_id = c.category_id
WHERE c.category_type = 'Expense'
GROUP BY u.user_name, EXTRACT(MONTH FROM t.transaction_date)
ORDER BY month;

###### 4.Which category has the highest expense overall?
SELECT 
    c.category_name,
    SUM(t.amount) AS total_spent
FROM transactions t
JOIN categories c ON t.category_id = c.category_id
WHERE c.category_type = 'Expense'
GROUP BY c.category_name
ORDER BY total_spent DESC
LIMIT 1;

####### 5.What is the net savings for each user?
SELECT 
    u.user_name,
    SUM(
        CASE 
            WHEN c.category_type = 'Income' THEN t.amount
            ELSE -t.amount
        END
    ) AS net_savings
FROM transactions t
JOIN users u ON t.user_id = u.user_id
JOIN categories c ON t.category_id = c.category_id
GROUP BY u.user_name;

######## 6.Which payment method is used most frequently?
SELECT 
    p.payment_method,
    COUNT(*) AS usage_count
FROM transactions t
JOIN payment_methods p ON t.payment_id = p.payment_id
GROUP BY p.payment_method
ORDER BY usage_count DESC;

####### 7.What is the average expense per transaction for each user?
SELECT 
    u.user_name,
    AVG(t.amount) AS avg_expense
FROM transactions t
JOIN users u ON t.user_id = u.user_id
JOIN categories c ON t.category_id = c.category_id
WHERE c.category_type = 'Expense'
GROUP BY u.user_name;

######## 8.Identify days where spending was unusually high (above average).
SELECT 
    transaction_date,
    SUM(amount) AS daily_spending
FROM transactions
GROUP BY transaction_date
HAVING SUM(amount) > (
    SELECT AVG(amount) FROM transactions
);

######## 9.What percentage of total expenses does each category contribute?
SELECT 
    c.category_name,
    ROUND(
        (SUM(t.amount) * 100.0) /
        (SELECT SUM(amount) 
         FROM transactions t2
         JOIN categories c2 ON t2.category_id = c2.category_id
         WHERE c2.category_type = 'Expense'),
    2) AS expense_percentage
FROM transactions t
JOIN categories c ON t.category_id = c.category_id
WHERE c.category_type = 'Expense'
GROUP BY c.category_name;

######### 10.Which user spends the highest percentage of their income?
SELECT 
    u.user_name,
    ROUND(
        (SUM(CASE WHEN c.category_type = 'Expense' THEN t.amount ELSE 0 END) * 100.0) /
        SUM(CASE WHEN c.category_type = 'Income' THEN t.amount ELSE 0 END),
    2) AS expense_to_income_ratio
FROM transactions t
JOIN users u ON t.user_id = u.user_id
JOIN categories c ON t.category_id = c.category_id
GROUP BY u.user_name
ORDER BY expense_to_income_ratio DESC;









